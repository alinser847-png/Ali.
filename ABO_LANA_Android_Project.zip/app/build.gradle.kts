plugins { id("com.android.application") }

android {
    namespace = "com.abolana.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.abolana.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
