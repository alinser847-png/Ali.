# ABO LANA Android
This is an Android Studio project wrapping the supplied ABO LANA HTML in a WebView.

Requirements:
- Android Studio
- Internet connection
- Android SDK 35

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect Samsung A16 with USB debugging enabled.
4. Run the app, or Build > Generate App Bundle(s) / APK(s) > Generate APK(s).

The app loads the HTML locally and the HTML fetches Binance market data over HTTPS/WSS.
Notifications are bridged to native Android notifications.
